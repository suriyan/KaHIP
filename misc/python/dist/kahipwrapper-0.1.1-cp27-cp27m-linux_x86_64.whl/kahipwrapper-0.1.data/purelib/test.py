import kaHIP

print kaHIP.kaffpa(5, None, [0,2,5,7,9,12], None, [1,4,0,2,4,1,3,2,4,0,1,3],2,0.03,False,0,kaHIP.FAST)

print kaHIP.kaffpa_balance_NE(5, None, [0,2,5,7,9,12], None, [1,4,0,2,4,1,3,2,4,0,1,3],2,0.03,False,0,kaHIP.FAST)
